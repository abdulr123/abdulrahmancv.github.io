# HTML-CSS-CV
CV-Using-HTML-CSS

This is a non-responsive CV, made using HTML and CSS only. (Just a practice)

Demo: https://ovi.github.io/HTML-CSS-CV/
